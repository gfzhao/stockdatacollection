# stockdatacollection
collect stock data from tushare, tonghuashun,sina finance,etc
